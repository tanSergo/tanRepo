import akka.actor.ActorRef;
import akka.actor.UntypedActor;
import akka.event.Logging;
import akka.event.LoggingAdapter;


/**
 *
 * Created by tan-hagen on 08.05.16.
 */

public class ShowerStall extends UntypedActor {

    static class Washing {
        private final Integer key;
        private final Checkpoint.Gender gender;

        public Washing(Integer key, Checkpoint.Gender gender) {
            this.key = key;
            this.gender = gender;
        }
    }

    LoggingAdapter log = Logging.getLogger(getContext().system(), this);


    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof Washing) {
            Washing washing = (Washing) message;
            log.info("Washing: " + washing.key + " - Cur_gen: " + washing.gender);
            ActorRef sender = getSender();
            sender.tell(new Checkpoint.BackFromShower(washing.key,
                    washing.gender),getSelf());
            getContext().stop(getSelf());
        }
        else unhandled(message);
    }
}
